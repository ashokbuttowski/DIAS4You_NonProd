import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
const sesClient = new SESClient({ region: "us-east-1" });

export const handler = async (event) => {
    try {
        console.log('Raw event:', JSON.stringify(event));
        
        const webhookData = event.body ? JSON.parse(event.body) : event;
        const email = webhookData?.payload?.payment?.entity?.email;
        console.log('Customer Email:', email);

        if (email) {
            const params = {
                Destination: {
                    //ToAddresses: 'awsarmory+code7989@gmail.com',
                    ToAddresses: [email],
                },
                Message: {
                    Body: {
                        Text: { Data: 'Your payment was successful www.dias4you.com dummy s3 link must be coming here' },
                    },
                    Subject: { Data: 'Dias4you Payment Confirmation' },
                },
                Source: 'd.n.raju21c@gmail.com',
            };

            const command = new SendEmailCommand(params);
            await sesClient.send(command);
            console.log('Email sent successfully');
        } else {
            console.log('Email not found in the event payload');
        }

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: 'Success',
                email: email || 'Not found',
            }),
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: error.message,
            }),
        };
    }
};