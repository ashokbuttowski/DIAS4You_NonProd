import { SESClient, SendRawEmailCommand } from "@aws-sdk/client-ses";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

const sesClient = new SESClient({ region: "us-east-1" });
const s3Client = new S3Client({ region: "us-east-1" });

const getS3File = async (bucket, key) => {
    const command = new GetObjectCommand({
        Bucket: bucket,
        Key: key
    });
    const response = await s3Client.send(command);
    const chunks = [];
    for await (const chunk of response.Body) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
};

export const handler = async (event) => {
    try {
        console.log('Raw event:', JSON.stringify(event));
        
        const webhookData = event.body ? JSON.parse(event.body) : event;
        const email = webhookData?.payload?.payment?.entity?.email;
        console.log('Customer Email:', email);

        if (email) {
            const s3Bucket = 'dias4you.com';
            const s3Key = 'PdfsFolder/SpokenEnglishToRiseFast.pdf';
            const attachment = await getS3File(s3Bucket, s3Key);
            
            const boundary = 'boundary-' + Date.now();
            const emailContent = Buffer.from(
                `From: d.n.raju21c@gmail.com\r\n` +
                `To: ${email}\r\n` +
                `Subject: Dias4you Payment Confirmation\r\n` +
                `MIME-Version: 1.0\r\n` +
                `Content-Type: multipart/mixed; boundary="${boundary}"\r\n\r\n` +
                `--${boundary}\r\n` +
                `Content-Type: text/plain; charset=utf-8\r\n\r\n` +
                `Your payment was successful www.dias4you.com\r\n\r\n` +
                `--${boundary}\r\n` +
                `Content-Type: application/pdf\r\n` +
                `Content-Transfer-Encoding: base64\r\n` +
                `Content-Disposition: attachment; filename="SpokenEnglishToRiseFast.pdf"\r\n\r\n`
            );

            const attachmentBase64 = attachment.toString('base64');
            const attachmentBuffer = Buffer.from(attachmentBase64, 'base64');
            const endBoundary = Buffer.from(`\r\n--${boundary}--\r\n`);

            const rawMessage = Buffer.concat([
                emailContent,
                Buffer.from(attachmentBase64),
                endBoundary
            ]);

            const params = {
                Source: 'd.n.raju21c@gmail.com',
                Destinations: [email],
                RawMessage: {
                    Data: rawMessage
                }
            };

            const command = new SendRawEmailCommand(params);
            await sesClient.send(command);
            console.log('Email sent successfully with attachment');
        } else {
            console.log('Email not found in the event payload');
        }

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Email sent successfully' })
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
        };
    }
};